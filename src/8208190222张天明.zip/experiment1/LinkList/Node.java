package experiment1.LinkList;

public class Node {
    public Node next = null;//下一个结点
    public int data;//结点数据
    public Node(){}
    public Node(int data){
        this.data = data;
    }
}
